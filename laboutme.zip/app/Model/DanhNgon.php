<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DanhNgon extends Model
{
    protected $table = "danhngon";
    protected $primaryKey = "id";
    public $timestamps =false;
}
