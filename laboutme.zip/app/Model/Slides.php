<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Slides extends Model
{
    protected $table = "slides";
    protected $primaryKey = "id";
    public $timestamps =false;
}
