<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Aboutme extends Model
{
    protected $table = "aboutme";
    protected $primaryKey = "id";
    public $timestamps =false;
}
