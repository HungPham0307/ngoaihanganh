<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ChangDuong extends Model
{
    protected $table = "changduong";
    protected $primaryKey = "id";
    public $timestamps =false;
}
