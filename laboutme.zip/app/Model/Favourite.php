<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Favourite extends Model
{
    protected $table = "favourite";
    protected $primaryKey = "id";
    public $timestamps =false;
}
