<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Favourite;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\FavouriteRequest;
use Illuminate\Support\Facades\Storage;

class FavouriteController extends Controller
{
    public function index(){
    	$objFavourite = DB::table('favourite')->paginate(getenv("ROW_COUT"));
    	return view('admin.favourite.index',compact('objFavourite'));
    	
    }

    public function trangThai($nid){
            $objItem = Favourite::FindOrFail($nid);
            if($objItem->active == '0'){
                $objItem->active = '1';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/active.gif'/>
                </a>";
            }else{
                $objItem->active = '0';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/deactive.gif'/>
                </a>";
            }
    }


    public function getAdd(){
    	return view('admin.favourite.add');
    }

    public function postAdd(FavouriteRequest $request){
    	$soThich= $request->sothich;
    	$check = Favourite::where('content','=',$soThich)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Sở thích bị trùng');
        	return redirect()->route('admin.favourite.getadd');
        }else{
	      
	        $arrItem = array(
           
            "content" =>$soThich,
           
          
        	);
	        if(Favourite::insert($arrItem)){
	             $request->session()->flash('msg','Thêm kĩ năng thành công');
	              return redirect()->route('admin.favourite.index');
	          }else{
	                $request->session()->flash('msg','Thêm thất bại');
	              return redirect()->route('admin.favourite.index');
	           }
	    }
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objFavourite = Favourite::FindOrFail($did);    

	        $objFavourite->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.favourite.index');
    	
    }

    public function getEdit($id){
    	$objFavourite= Favourite::FindOrFail($id);
    	return view('admin.favourite.edit',compact('objFavourite'));
    }

    public function postEdit($id,FavouriteRequest $request){
    	$objFavourite = Favourite::FindOrFail($id);
        $soThich = $request ->sothich;
        $check = Favourite::where('content','=',$soThich)->where('id','!=',$id)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Sở thích bị trùng');
        	return redirect()->route('admin.favourite.getedit',$id);
        }else{

	      

	       $objFavourite->content = $soThich;

       	if($objFavourite->update()){
            $request->session()->flash('msg','Sửa thành công');
            return redirect()->route('admin.favourite.index');
       }else{
            $request->session()->flash('msg','Sửa thất bại');
          return redirect()->route('admin.favourite.getedit',$id);
       }
     
    }
}
}
