<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\ChangDuong;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\ChangDuongRequest;
use Illuminate\Support\Facades\Storage;
class ChangDuongController extends Controller
{
    public function index(){
    	$objChangDuong = DB::table('changduong')->paginate(getenv("ROW_COUT"));
    	return view('admin.changduong.index',compact('objChangDuong'));
    }

    public function getAdd(){
    	return view('admin.changduong.add');
    }

    public function postAdd(ChangDuongRequest $request){
    	$tieuDe= $request->tieude;
    	$check = ChangDuong::where('name','=',$tieuDe)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Tiêu đề bị trùng');
        	return redirect()->route('admin.changduong.getadd');
        }else{
	       $picture = $request ->hinhanh;

	        $arrItem = array(
            "name" => $tieuDe,
            "content" =>$request ->mota,
            "time" =>$request ->thoigian,
          
        	);
	        if($picture !=""){
	            $tmp = $request->file("hinhanh")->store("files/");
	            $arr = explode("/",$tmp);
	            $namePic = end($arr);
	            $arrItem["picture"] =$namePic;
	        }else{
	             $arrItem["picture"] ="";
	        }

	        if(ChangDuong::insert($arrItem)){
	             $request->session()->flash('msg','Thêm chặng đường đã qua thành công');
	              return redirect()->route('admin.changduong.index');
	          }else{
	                $request->session()->flash('msg','Thêm thất bại');
	              return redirect()->route('admin.changduong.index');
	           }
	    }
    }



    public function trangThai($nid){
            $objItem = ChangDuong::find($nid);
            if($objItem->active == '0'){
                $objItem->active = '1';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/active.gif'/>
                </a>";
            }else{
                $objItem->active = '0';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/deactive.gif'/>
                </a>";
            }
    }


    public function getEdit($id){
    	$objChangDuong= ChangDuong::FindOrFail($id);
    	return view('admin.changduong.edit',compact('objChangDuong'));
    }

    public function postEdit($id,ChangDuongRequest $request){
    	$objChangDuong = ChangDuong::FindOrFail($id);
        $tieuDe = $request ->tieude;
        $check = ChangDuong::where('name','=',$tieuDe)->where('id','!=',$id)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Nội dung  bị trùng');
        	return redirect()->route('admin.changduong.getedit',$id);
        }else{

	       $objChangDuong->name = $tieuDe;

	       $objChangDuong->content = $request ->mota;
	       $objChangDuong->time = $request ->thoigian;
	      
	       $picture = $request ->hinhanh;

		    if(isset($request->delete_picture)){ //giao diện có hiện thị ra checkbox nhưng k chọn thì vẫn k tồn tại
	            
	            $oldPic = $objChangDuong->picture;
	         
	            storage::delete("files/".$oldPic);

	            if($picture !=""){
	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                $objChangDuong->picture = $namePic;
	            }else{
	                $objChangDuong->picture="";
	            }
	      
	        }else{

	            if($picture !=""){
	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                
	                //xóa ảnh cũ
	                $oldPic = $objChangDuong->picture;
	                if($oldPic != ""){
	                    storage::delete("files/".$oldPic);
	                }
	                $objChangDuong->picture = $namePic;
	            
	            }
	        }
        }


       	if($objChangDuong->update()){
            $request->session()->flash('msg','Sửa thành công');
            return redirect()->route('admin.changduong.index');
       }else{
            $request->session()->flash('msg','Sửa thất bại');
          return redirect()->route('admin.changduong.getedit',$id);
       }
     
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objChangDuong = ChangDuong::FindOrFail($did);    	
        	$namePic = $objChangDuong->picture;

	        if($namePic !=""){
	            storage::delete("files/".$namePic);
	        }

	        $objChangDuong->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.changduong.index');
    	
    }
}
