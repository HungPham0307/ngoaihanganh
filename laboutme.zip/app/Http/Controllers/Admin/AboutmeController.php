<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Aboutme;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\AboutmeRequest;
use Illuminate\Support\Facades\Storage;

class AboutmeController extends Controller
{
     public function index(){
    	$objAboutme = DB::table('aboutme')->paginate(getenv("ROW_COUT"));
    	return view('admin.aboutme.index',compact('objAboutme'));
    }

    public function trangThai($nid){
            $objItem = Aboutme::FindOrFail($nid);
            if($objItem->active == '0'){
                $objItem->active = '1';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/active.gif'/>
                </a>";
            }else{
                $objItem->active = '0';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/deactive.gif'/>
                </a>";
            }
    }


    public function getAdd(){
    	return view('admin.aboutme.add');
    }

    public function postAdd(AboutmeRequest $request){
    	$noiDung= $request->noidung;
    	$check = Aboutme::where('content','=',$noiDung)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Nội dung  bị trùng');
        	return redirect()->route('admin.aboutme.getadd');
        }else{
	       $picture = $request ->hinhanh;

	       if($picture ==""){
	       		$request->session()->flash('msg','Vui lòng chọn ảnh');
        		return redirect()->route('admin.aboutme.getadd');
        		die();
	       }

	        $arrItem = array(
            
            "content" =>$noiDung,
           
           
          
        	);
	       
	        $tmp = $request->file("hinhanh")->store("files/");
	        $arr = explode("/",$tmp);
	        $namePic = end($arr);
	        $arrItem["picture"] =$namePic;
	        
	        if(Aboutme::insert($arrItem)){
	             $request->session()->flash('msg','Thêm   thành công');
	              return redirect()->route('admin.aboutme.index');
	          }else{
	                $request->session()->flash('msg','Thêm thất bại');
	              return redirect()->route('admin.aboutme.index');
	           }
	    }
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objAboutme = Aboutme::FindOrFail($did);    	
        	$namePic = $objAboutme->picture;

	        if($namePic !=""){
	            storage::delete("files/".$namePic);
	        }

	        $objAboutme->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.aboutme.index');
    	
    }

    public function getEdit($id){
    	$objAboutme= Aboutme::FindOrFail($id);
    	return view('admin.aboutme.edit',compact('objAboutme'));
    }

    public function postEdit($id,AboutmeRequest $request){
    	$objAboutme = Aboutme::FindOrFail($id);
        $noiDung = $request ->noidung;
        $check = Aboutme::where('content','=',$noiDung)->where('id','!=',$id)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Nội dung  bị trùng');
        	return redirect()->route('admin.aboutme.getedit',$id);
        }else{

	       $objAboutme->content = $noiDung;
	      
	       $picture = $request ->hinhanh;

		    if(isset($request->delete_picture)){ //giao diện có hiện thị ra checkbox nhưng k chọn thì vẫn k tồn tại
	            if($picture ==""){
	            	$request->session()->flash('msg','Vui lòng chọn ảnh');
	        		return redirect()->route('admin.aboutme.getedit',$id);
	        		die();
	            }
	            $oldPic = $objAboutme->picture;
	         
	            storage::delete("files/".$oldPic);

	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                $objAboutme->picture = $namePic;
	          


			     if($objAboutme->update()){
		            $request->session()->flash('msg','Sửa thành công');
		            return redirect()->route('admin.aboutme.index');
		       	}else{
		            $request->session()->flash('msg','Sửa thất bại');
		          return redirect()->route('admin.aboutme.getedit',$id);
		       	}
	        }else{

	            if($picture !=""){
	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                
	                //xóa ảnh cũ
	                $oldPic = $objAboutme->picture;
	                if($oldPic != ""){
	                    storage::delete("files/".$oldPic);
	                }
	                $objAboutme->picture = $namePic;


	                if($objAboutme->update()){
			            $request->session()->flash('msg','Sửa thành công');
			            return redirect()->route('admin.aboutme.index');
			       	}else{
			            $request->session()->flash('msg','Sửa thất bại');
			          return redirect()->route('admin.aboutme.getedit',$id);
			       }
	            
		            }else{
		            	if($objAboutme->update()){
				            $request->session()->flash('msg','Sửa thành công');
				            return redirect()->route('admin.aboutme.index');
				       	}else{
				            $request->session()->flash('msg','Sửa thất bại');
				          return redirect()->route('admin.aboutme.getedit',$id);
				       }
		            }
	        }
        }


       	if($objAboutme->update()){
            $request->session()->flash('msg','Sửa thành công');
            return redirect()->route('admin.aboutme.index');
       	}else{
            $request->session()->flash('msg','Sửa thất bại');
          return redirect()->route('admin.aboutme.getedit',$id);
       }
    }
}
