<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Slides;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SlidesRequest;
use Illuminate\Support\Facades\Storage;
class SlidesController extends Controller
{
    public function index(){
    	$objSlides = DB::table('slides')->paginate(getenv("ROW_COUT"));
    	return view('admin.slides.index',compact('objSlides'));
    	
    }

    public function trangThai($nid){
            $objItem = Slides::FindOrFail($nid);
            if($objItem->active == '0'){
                $objItem->active = '1';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/active.gif'/>
                </a>";
            }else{
                $objItem->active = '0';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/deactive.gif'/>
                </a>";
            }
    }


    public function getAdd(){
    	return view('admin.slides.add');
    }

    public function postAdd(SlidesRequest $request){
    	$ten= $request->tieude;
    	$check = Slides::where('title','=',$ten)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Tên bị trùng');
        	return redirect()->route('admin.slides.getadd');
        }else{
	      
	        $arrItem = array(
            "title" => $ten,
            "content" =>$request ->mota,
           
          
        	);
	        if(Slides::insert($arrItem)){
	             $request->session()->flash('msg','Thêm slides thành công');
	              return redirect()->route('admin.slides.index');
	          }else{
	                $request->session()->flash('msg','Thêm thất bại');
	              return redirect()->route('admin.slides.index');
	           }
	    }
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objSlides = Slides::FindOrFail($did);    

	        $objSlides->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.slides.index');
    	
    }

    public function getEdit($id){
    	$objSlides= Slides::FindOrFail($id);
    	return view('admin.slides.edit',compact('objSlides'));
    }

    public function postEdit($id,SlidesRequest $request){
    	$objSlides = Slides::FindOrFail($id);
        $title = $request ->tenkinang;
        $check = Slides::where('title','=',$title)->where('id','!=',$id)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Tên kĩ năng bị trùng');
        	return redirect()->route('admin.slides.getedit',$id);
        }else{

	       $objSlides->title = $title;

	       $objSlides->content = $request ->mota;

       	if($objSlides->update()){
            $request->session()->flash('msg','Sửa thành công');
            return redirect()->route('admin.slides.index');
       }else{
            $request->session()->flash('msg','Sửa thất bại');
          return redirect()->route('admin.slides.getedit',$id);
       }
     
    }
}
}
