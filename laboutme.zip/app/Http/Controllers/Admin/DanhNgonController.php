<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\DanhNgon;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\DanhNgonRequest;
use Illuminate\Support\Facades\Storage;
class DanhNgonController extends Controller
{
    public function index(){
    	$objDN = DB::table('danhngon')->paginate(getenv("ROW_COUT"));
    	return view('admin.danhngon.index',compact('objDN'));
    }

    public function trangThai($nid){
            $objItem = DanhNgon::FindOrFail($nid);
            if($objItem->active == '0'){
                $objItem->active = '1';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/active.gif'/>
                </a>";
            }else{
                $objItem->active = '0';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/deactive.gif'/>
                </a>";
            }
    }


    public function getAdd(){
    	return view('admin.danhngon.add');
    }

    public function postAdd(DanhNgonRequest $request){
    	$noiDung= $request->noidung;
    	$check = DanhNgon::where('noidung','=',$noiDung)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Nội dung bị trùng');
        	return redirect()->route('admin.danhngon.getadd');
        }else{
	       $picture = $request ->hinhanh;

	        $arrItem = array(
            "noidung" => $noiDung,
            "tacgia" =>$request ->tacgia,
           
          
        	);
	        if($picture !=""){
	            $tmp = $request->file("hinhanh")->store("files/");
	            $arr = explode("/",$tmp);
	            $namePic = end($arr);
	            $arrItem["hinhanh"] =$namePic;
	        }else{
	             $arrItem["hinhanh"] ="";
	        }

	        if(DanhNgon::insert($arrItem)){
	             $request->session()->flash('msg','Thêm danh ngôn thành công');
	              return redirect()->route('admin.danhngon.index');
	          }else{
	                $request->session()->flash('msg','Thêm thất bại');
	              return redirect()->route('admin.danhngon.index');
	           }
	    }
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objDN = DanhNgon::FindOrFail($did);    	
        	$namePic = $objDN->hinhanh;

	        if($namePic !=""){
	            storage::delete("files/".$namePic);
	        }

	        $objDN->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.danhngon.index');
    	
    }

    public function getEdit($id){
    	$objDN= DanhNgon::FindOrFail($id);
    	return view('admin.danhngon.edit',compact('objDN'));
    }

    public function postEdit($id,DanhNgonRequest $request){
    	$objDN = DanhNgon::FindOrFail($id);
        $noiDung = $request ->noidung;
        $check = DanhNgon::where('noidung','=',$noiDung)->where('id','!=',$id)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Nội dung danh ngôn bị trùng');
        	return redirect()->route('admin.danhngon.getedit',$id);
        }else{

	       $objDN->noidung = $noiDung;

	       $objDN->tacgia = $request ->tacgia;
	      
	      
	       $picture = $request ->hinhanh;

		    if(isset($request->delete_picture)){ //giao diện có hiện thị ra checkbox nhưng k chọn thì vẫn k tồn tại
	            
	            $oldPic = $objDN->hinhanh;
	         
	            storage::delete("files/".$oldPic);

	            if($picture !=""){
	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                $objDN->hinhanh = $namePic;
	            }else{
	                $objDN->hinhanh="";
	            }
	      
	        }else{

	            if($picture !=""){
	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                
	                //xóa ảnh cũ
	                $oldPic = $objDN->hinhanh;
	                if($oldPic != ""){
	                    storage::delete("files/".$oldPic);
	                }
	                $objDN->hinhanh = $namePic;
	            
	            }
	        }
        }


       	if($objDN->update()){
            $request->session()->flash('msg','Sửa thành công');
            return redirect()->route('admin.danhngon.index');
       }else{
            $request->session()->flash('msg','Sửa thất bại');
          return redirect()->route('admin.danhngon.getedit',$id);
       }
     
    }
}
