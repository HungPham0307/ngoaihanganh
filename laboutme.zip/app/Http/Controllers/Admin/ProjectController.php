<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Project;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\ProjectRequest;
use Illuminate\Support\Facades\Storage;

class ProjectController extends Controller
{
   public function index(){
    	$objProject = DB::table('project')->paginate(getenv("ROW_COUT"));
    	return view('admin.project.index',compact('objProject'));
    }

    public function getAdd(){
    	return view('admin.project.add');
    }

    public function postAdd(ProjectRequest $request){
    	$title= $request->tenduan;
    	$check = Project::where('title','=',$title)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Tên dự án  bị trùng');
        	return redirect()->route('admin.project.getadd');
        }else{
	       $picture = $request ->hinhanh;

	       if($picture ==""){
	       		$request->session()->flash('msg','Vui lòng chọn ảnh');
        		return redirect()->route('admin.project.getadd');
        		die();
	       }

	        $arrItem = array(
            "title" => $title,
            "content" =>$request ->mota,
            "link" =>$request ->link,
           // "picture" =>$picture
          
        	);
	       
	        $tmp = $request->file("hinhanh")->store("files/");
	        $arr = explode("/",$tmp);
	        $namePic = end($arr);
	        $arrItem["picture"] =$namePic;
	        
	        if(Project::insert($arrItem)){
	             $request->session()->flash('msg','Thêm dự án  thành công');
	              return redirect()->route('admin.project.index');
	          }else{
	                $request->session()->flash('msg','Thêm thất bại');
	              return redirect()->route('admin.project.index');
	           }
	    }
    }



    public function trangThai($nid){
            $objItem = Project::find($nid);
            if($objItem->active == '0'){
                $objItem->active = '1';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/active.gif'/>
                </a>";
            }else{
                $objItem->active = '0';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/deactive.gif'/>
                </a>";
            }
    }


    public function getEdit($id){
    	$objProject= Project::FindOrFail($id);
    	return view('admin.project.edit',compact('objProject'));
    }

    public function postEdit($id,ProjectRequest $request){
    	$objProject = Project::FindOrFail($id);
        $tieuDe = $request ->tenduan;
        $check = Project::where('title','=',$tieuDe)->where('id','!=',$id)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Tên dự án  bị trùng');
        	return redirect()->route('admin.project.getedit',$id);
        }else{

	       $objProject->title = $tieuDe;
	       $objProject->content = $request ->mota;
	       $objProject->link = $request ->link;
	       $picture = $request ->hinhanh;

		    if(isset($request->delete_picture)){ //giao diện có hiện thị ra checkbox nhưng k chọn thì vẫn k tồn tại
	            if($picture ==""){
	            	$request->session()->flash('msg','Vui lòng chọn ảnh');
	        		return redirect()->route('admin.project.getedit',$id);
	        		die();
	            }
	            $oldPic = $objProject->picture;
	         
	            storage::delete("files/".$oldPic);

	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                $objProject->picture = $namePic;
	          


			     if($objProject->update()){
		            $request->session()->flash('msg','Sửa thành công');
		            return redirect()->route('admin.project.index');
		       	}else{
		            $request->session()->flash('msg','Sửa thất bại');
		          return redirect()->route('admin.project.getedit',$id);
		       	}
	        }else{

	            if($picture !=""){
	                $tmp = $request->file("hinhanh")->store("files/");
	                $arr = explode("/",$tmp);
	                $namePic = end($arr);
	                
	                //xóa ảnh cũ
	                $oldPic = $objProject->picture;
	                if($oldPic != ""){
	                    storage::delete("files/".$oldPic);
	                }
	                $objProject->picture = $namePic;


	                if($objProject->update()){
			            $request->session()->flash('msg','Sửa thành công');
			            return redirect()->route('admin.project.index');
			       	}else{
			            $request->session()->flash('msg','Sửa thất bại');
			          return redirect()->route('admin.project.getedit',$id);
			       }
	            
	            }else{
	            	if($objProject->update()){
			            $request->session()->flash('msg','Sửa thành công');
			            return redirect()->route('admin.project.index');
			       	}else{
			            $request->session()->flash('msg','Sửa thất bại');
			          return redirect()->route('admin.project.getedit',$id);
			       }
	            }
	        }
        }


       	if($objProject->update()){
            $request->session()->flash('msg','Sửa thành công');
            return redirect()->route('admin.project.index');
       	}else{
            $request->session()->flash('msg','Sửa thất bại');
          return redirect()->route('admin.project.getedit',$id);
       }
     
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objProject = Project::FindOrFail($did);    	
        	$namePic = $objProject->picture;

	        if($namePic !=""){
	            storage::delete("files/".$namePic);
	        }

	        $objProject->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.project.index');
    	
    }
}
