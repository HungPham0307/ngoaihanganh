<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Skill;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\SkillRequest;
use Illuminate\Support\Facades\Storage;
class SkillController extends Controller
{
    public function index(){
    	$objSkill = DB::table('skill')->paginate(getenv("ROW_COUT"));
    	return view('admin.skill.index',compact('objSkill'));
    	
    }

    public function trangThai($nid){
            $objItem = Skill::FindOrFail($nid);
            if($objItem->active == '0'){
                $objItem->active = '1';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/active.gif'/>
                </a>";
            }else{
                $objItem->active = '0';
                $objItem->update();
                echo "<a href='javascript:void(0)' onclick='getTrangThai( {$nid});'>
                     <img src='/resources/assets/templates/admin/images/deactive.gif'/>
                </a>";
            }
    }


    public function getAdd(){
    	return view('admin.skill.add');
    }

    public function postAdd(SkillRequest $request){
    	$ten= $request->tenkinang;
    	$check = Skill::where('title','=',$ten)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Tên bị trùng');
        	return redirect()->route('admin.skill.getadd');
        }else{
	      
	        $arrItem = array(
            "title" => $ten,
            "content" =>$request ->mota,
           
          
        	);
	        if(Skill::insert($arrItem)){
	             $request->session()->flash('msg','Thêm kĩ năng thành công');
	              return redirect()->route('admin.skill.index');
	          }else{
	                $request->session()->flash('msg','Thêm thất bại');
	              return redirect()->route('admin.skill.index');
	           }
	    }
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objSkill = Skill::FindOrFail($did);    

	        $objSkill->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.skill.index');
    	
    }

    public function getEdit($id){
    	$objSkill= Skill::FindOrFail($id);
    	return view('admin.skill.edit',compact('objSkill'));
    }

    public function postEdit($id,SkillRequest $request){
    	$objSkill = Skill::FindOrFail($id);
        $title = $request ->tenkinang;
        $check = Skill::where('title','=',$title)->where('id','!=',$id)->first();
       
        if($check != null){
        	$request->session()->flash('msg','Tên kĩ năng bị trùng');
        	return redirect()->route('admin.skill.getedit',$id);
        }else{

	       $objSkill->title = $title;

	       $objSkill->content = $request ->mota;

       	if($objSkill->update()){
            $request->session()->flash('msg','Sửa thành công');
            return redirect()->route('admin.skill.index');
       }else{
            $request->session()->flash('msg','Sửa thất bại');
          return redirect()->route('admin.skill.getedit',$id);
       }
     
    }
}
}
