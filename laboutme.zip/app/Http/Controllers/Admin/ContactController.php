<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Contact;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\ContactRequest;
use Illuminate\Support\Facades\Storage;
use Mail;
use App\mail\sendMail;
class ContactController extends Controller
{
    public function index(){
    	$objContact = DB::table('contact')->paginate(getenv("ROW_COUT"));
    	return view('admin.contact.index',compact('objContact'));
    	
    }

    public function del(Request $request){   
     	$id = $request->xoa;
     	foreach($id as $did){

     		$objContact = Contact::FindOrFail($did);    

	        $objContact->delete();
     	}
     	$request->session()->flash('msg','Xóa thành công');
         return redirect()->route('admin.contact.index');
    	
    }

    public function getReply($id){
    	$objContact = Contact::FindOrFail($id);
    	return view('admin.contact.reply',compact('objContact'));
    }

    public function postReply(Request $request,$id){
    	$noiDung = $request->message;
    	$request->session()->flash('noidung',$noiDung);//gửi qua view mail
    	$formdata = $request->except('_token');
    	Mail::send(new sendMail($formdata));
    	$request->session()->flash('msg','Trả lời thành công');
         return redirect()->route('admin.contact.index');
    }
 


}
