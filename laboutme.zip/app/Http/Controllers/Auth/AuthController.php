<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\UserRequest;
use App\Http\Requests\getPassRequest;
use App\Http\Requests\confirmedPassRequest;
use App\Model\User;
use Mail;
use App\mail\sendMail;
class AuthController extends Controller
{
    public function getLogin(){
    	return view('admin.user.login');
    }

    public function postLogin(Request $request){
    	$userName = trim($request->username);
        $passWord = trim($request->password);

        if(Auth::attempt([
                "username"=>$userName,
                "password"=>$passWord,
                "active"=>1
        ])){

            $request->session()->put('name', $userName);
        
            return redirect()->route("admin.index.index"); 

        }else{
            if(Auth::attempt([
                "username"=>$userName,
                "password"=>$passWord,
                "active"=>0
              ])){
                $request->session()->flash('msg','Tài khoản bị khóa');
                return redirect()->route("admin.user.getlogin"); 
            }else{
                $request->session()->flash('msg','Tài khoản không đúng');
                return redirect()->route("admin.user.getlogin");
            }
            
        }
    }
    public function logout(Request $request){
         $request->session()->forget('name');
    	 Auth::logout();
    	//return view('admin.user.login');
        return redirect()->route("admin.user.getlogin");
    }

    public function postPass(getPassRequest $request){
        $email =  $request->mail;
        $objUser = User::where('email','=',$email)->first();
        
        if($objUser ==null){

            $request->session()->flash('msg','Email k đúng ! Vui lòng kiểm tra lại');
            return redirect()->route("admin.user.getlogin");
        }else{
            $id = $objUser->id;
            $data =mt_rand(1000, 9999);
            $request->session()->put('data',$data);//tạo session để lưu mã xác nhận
            $noidung = "Mã xác nhận tài khoản của bạn là : {$data}";
            $request->session()->flash('noidung',$noidung);
            $formdata = $request->except('_token');
            Mail::send(new sendMail($formdata));

            
           // return redirect()->route('admin.user.getxacnhan',$id);

            return view('admin.user.xacnhan',compact('objUser'));
        }
       
    }

    public function getXacNhan($id){
        $objUser = User::FindOrFail($id);
        return view('admin.user.xacnhan',compact('objUser'));
    }





    public function getNewPass($id){
        $objUser = User::FindOrFail($id);
        return view('admin.user.pass',compact('objUser'));
    }

    public function postNewPass(Request $request,$id){
        $maSo = $request->xacnhan;
        if( $request->session()->has('data') &&  $request->session()->get('data')==$maSo){
            return view('admin.user.pass',['id'=>$id]);
        }else{
            $request->session()->flash('msg','Mã số không đúng');
             $objUser = User::FindOrFail($id);
            return view('admin.user.xacnhan',compact('objUser'));
        }
    }


    public function done(confirmedPassRequest $request,$id){
       
         $objUser = User::FindOrFail($id);
         $passWord = bcrypt(trim($request->password));
         $objUser->password=$passWord;
         if($objUser->update()){
                $request->session()->flash('msg','Đăng nhập ngay');
                return redirect()->route('admin.user.getlogin');
           }else{
                $request->session()->flash('msg','Vui lòng kiểm tra lại');
                return redirect()->route('admin.user.getlogin');
            }
    }
}
