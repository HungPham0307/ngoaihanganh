<?php

namespace App\Http\Controllers\Aboutme;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Slides;
use App\Model\ChangDuong;
use App\Model\DanhNgon;
use App\Model\Skill;
use App\Model\Project;
use App\Model\Aboutme;
use App\Model\Contact;
use App\Model\Favourite;
use App\Http\Requests\ContactRequest;
use Illuminate\Support\Facades\DB;
class IndexController extends Controller
{
    public function index() {
    	$objSlides = Slides::where('active','=','1')->get();
    	$objChangDuong = ChangDuong::where('active','=','1')->get();
    	$objDanhNgon = DanhNgon::where('active','=','1')->get();
    	$objSkill = Skill::where('active','=','1')->get();
    	$objProject = Project::where('active','=','1')->get();
        $objFavourite = Favourite::where('active','=','1')->get();
        $objAboutme = Aboutme::where('active','=','1')->orderBy('id','DESC')->first();

    	return view('aboutme.index.index',compact('objSlides','objChangDuong','objDanhNgon','objSkill','objProject','objCat','objAboutme','objFavourite'));
    }

  
    public function postContact(ContactRequest $request){
    	$name = $request->name;
    	$email = $request->email;
    	$title = $request->title;
    	$content = $request->content;

    	
    	$addNew = array(
    			"name" =>$name,
    			"email" =>$email,
    			"title" =>$title,
    			"content" =>$content,
    			
    		);

    	 if(Contact::insert($addNew)){
	       	 $request->session()->flash('msg','Cảm ơn bạn đã liên hệ với tôi !');
	          return redirect()->route('aboutme.news.index');
	      }else{
	            $request->session()->flash('msg','Liên hệ thất bại');
	          return redirect()->route('aboutme.news.index');
	       }
    }
}
