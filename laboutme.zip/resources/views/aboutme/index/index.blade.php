@extends('templates.aboutme.master')
@section('main-content')

        <!--
        End Fixed Navigation
        ==================================== -->
		
		<main class="site-content" role="main">
		
        <!--
        Home Slider
        ==================================== -->
		
		<section id="home-slider">
            <div id="slider" class="sl-slider-wrapper">

				<div class="sl-slider">
					@foreach($objSlides as $val )
						@php
							$id = $val ->id;
							$title = $val ->title;
							$content =$val->content;

						@endphp
						
						
						@if($id%2==0)
						<div class="sl-slide" data-orientation="horizontal" data-slice1-rotation="-25" data-slice2-rotation="-25" data-slice1-scale="2" data-slice2-scale="2">

							<div class="bg-img bg-img-1"></div>

							<div class="slide-caption">
	                            <div class="caption-content">
	                                <h2 class="animated fadeInDown">{{$title}}</h2>
	                                <span class="animated fadeInDown">{{$content}}</span>
	                                
	                            </div>
	                        </div>
							
						</div>
						@else
						
						<div class="sl-slide" data-orientation="vertical" data-slice1-rotation="10" data-slice2-rotation="-15" data-slice1-scale="1.5" data-slice2-scale="1.5">
						
							<div class="bg-img bg-img-2"></div>
							<div class="slide-caption">
	                            <div class="caption-content">
	                                <h2>{{$title}}</h2>
	                                <span>{{$content}}</span>
	                                
	                            </div>
	                        </div>
							
						</div>
						
						@endif
					
					@endforeach
					

				</div><!-- /sl-slider -->

                <!-- 
                <nav id="nav-arrows" class="nav-arrows">
                    <span class="nav-arrow-prev">Previous</span>
                    <span class="nav-arrow-next">Next</span>
                </nav>
                -->
                
                <nav id="nav-arrows" class="nav-arrows hidden-xs hidden-sm visible-md visible-lg">
                    <a href="javascript:;" class="sl-prev">
                        <i class="fa fa-angle-left fa-3x"></i>
                    </a>
                    <a href="javascript:;" class="sl-next">
                        <i class="fa fa-angle-right fa-3x"></i>
                    </a>
                </nav>
                

				<nav id="nav-dots" class="nav-dots visible-xs visible-sm hidden-md hidden-lg">
					<span class="nav-dot-current"></span>
					<span></span>
					<span></span>
				</nav>

			</div><!-- /slider-wrapper -->
		</section>
		
        <!--
        End Home SliderEnd
        ==================================== -->
			
			<!-- about section -->
		<section id="about" style="background-color: #7F7D80;">
				<div class="container">
					<div class="row">
						<div class="col-md-4 wow animated fadeInLeft">
							<div class="recent-works">
								<h3>Sở thích</h3>
								<div id="works">
								@foreach($objFavourite as $val )
									@php
										$id = $val ->id;
										
										$content =$val->content;

									@endphp
						
									<div class="work-item">
										<p>{{$content}}</p>
									</div>
									@endforeach
								</div>
							</div>
						</div>
						<div class="col-md-7 col-md-offset-1 wow animated fadeInRight">
							<div class="welcome-block">
								@if(isset($objAboutme))
								<h3>Giới thiệu bản thân</h3>	
								
						     	 <div class="message-body">
									<img src="{{$imgUrl}}/{{$objAboutme->picture}}" class="pull-left" alt="member">
						       		<p>{{$objAboutme->content}}</p>
						     	 </div>
						       	@endif
						    </div>
						</div>
					</div>
				</div>
			</section>	
			<!-- end about section -->
	<section style="background-color: #00AEFF" >
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Chặng đường đã qua</h2>
                    <h3 class="section-subheading text-muted" style="color: white">Chinh phục bản thân </h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="timeline">
                    	@foreach($objChangDuong as $val )

                    	@php
							$id = $val ->id;
							$title = $val ->name;
							$content =$val->content;
							$picture = $val ->picture;
							$time = $val->time;

						@endphp
						
					
						@if($id%2!=0)
                        <li>
                            <div class="timeline-image">
                                <img class="img-circle img-responsive"  style="height: 156px " width="156"  src="{{$imgUrl}}/{{$picture}}" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 style="color: black" >{{$time}}</h4>
                                    <h4 class="subheading" style="color: green">{{$title}}</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted" style="color: white">{{$content}}</p>
                                </div>
                            </div>
                        </li>
                        @else
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                                <img class="img-circle img-responsive" src="{{$imgUrl}}/{{$picture}}" style="height: 156px " width="156" alt="">
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4 style="color: black">{{$time}}</h4>
                                    <h4 class="subheading" style="color: green">{{$title}}</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted" style="color: white">{{$content}}</p>
                                </div>
                            </div>
                        </li>
                       @endif
                      @endforeach
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                                <h4>To be
                                    
                                    <br>Continue!</h4>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
			
			<!-- Service section -->
			<section id="service" style="background-color: #F0F0F0">
				<div class="container">
					<div class="row">
					
						<div class="sec-title text-center">
							<h2 class="wow animated bounceInLeft">Kĩ Năng Mềm</h2>
							<p class="wow animated bounceInRight">Không ngừng tìm tòi để phát triển bản thân</p>
						</div>
						
						@foreach($objSkill as $val )

                    	@php
							
							$title = $val ->title;
							$content =$val->content;
							

						@endphp

						<div class="col-md-3 col-sm-6 col-xs-12 text-center wow animated zoomIn" data-wow-delay="0.3s">
							<div class="service-item">
								<div class="service-icon">
									<i class="fa fa-tasks fa-3x"></i>
								</div>
								<h3>{{$title}}</h3>
								<p>{{$content}}</p>
							</div>
						</div>
					
						
						@endforeach
						
					</div>
				</div>
			</section>
			<!-- end Service section -->
			
			<!-- portfolio section -->
			<section id="portfolio">
				<div class="container">
					<div class="row">
					
						<div class="sec-title text-center wow animated fadeInDown">
							<h2>Dự án đã thực hiện</h2>
							<p>Các dự án tôi đã thực hiện trong thời gian qua</p>
						</div>
						
						
					
						<ul class="project-wrapper wow animated fadeInUp">
							@foreach($objProject as $val )

	                    	@php
								
								$title = $val ->title;
								$content =$val->content;
								$picture =$val->picture;
								$link =$val->link;

							@endphp
							<li class="portfolio-item">
								<img src="{{$imgUrl}}/{{$picture}}" class="img-responsive" alt="{{$title}}" width="376px" height="285px">
								<figcaption class="mask">
									<h3>{{$title}}</h3>
									<p>{{$content}}</p>
								</figcaption>
								<ul class="external">
									<li><a class="fancybox" title="Araund The world" data-fancybox-group="works" href="{{$link}}"><i class="fa fa-search"></i></a></li>
									
								</ul>
							</li>
							@endforeach
						</ul>
						

						
					</div>
				</div>
			</section>
			<!-- end portfolio section -->
			
			<!-- Testimonial section -->
			<section id="testimonials" class="parallax">
				<div class="overlay">
					<div class="container">
						<div class="row">
						
							<div class="sec-title text-center white wow animated fadeInDown">
								<h2>Danh Ngôn Yêu thích</h2>
							</div>
							
							<div id="testimonial" class=" wow animated fadeInUp">
								@foreach($objDanhNgon as $val )

			                    	@php
										$id = $val ->id;
										$tacGia = $val ->tacgia;
										$noiDung =$val->noidung;
										$hinhAnh = $val ->hinhanh;
										

									@endphp
						
								<div class="testimonial-item text-center">
									<img src="{{$imgUrl}}/{{$hinhAnh}}
									" alt="Our Clients">
									<div class="clearfix">
										<span>{{$tacGia}}</span>
										<p>{{$noiDung}}</p>
									</div>
								</div>
								
								@endforeach
							</div>
						
						</div>
					</div>
				</div>
			</section>
			<!-- end Testimonial section -->
			
			
			
			<!-- Social section -->
			<section id="social" class="parallax">
				<div class="overlay">
					<div class="container">
					<div class="row">
						
						<div class="sec-title text-center wow animated fadeInDown">
							<h2 style="color: white" >Liên hệ </h2>
							 @if(Session::has("msg"))
					        	 <p style="color: white">{{Session::get("msg")}}</p> 
					         @endif
							<!--<p style="color: white">Leave a Message</p> -->
						</div>
						<p class="wow animated bounceInRight" style="color:white">Liên hệ với tôi, tôi sẽ sớm phản hồi mail của  bạn ! </p>
						
						<div class="col-md-7 contact-form wow animated fadeInLeft">
							<form action="{{route('aboutme.index.postcontact')}}" method="post">
							{{csrf_field()}}
								<div class="input-field">
									<input type="text" name="name" class="form-control" placeholder="Tên của bạn ... " required>
									@if ($errors->has('name'))
			              			 <span style="color: red;">
			              				 {{ array_first($errors->get('name')) }}
			              			 </span>
              						@endif
								</div>
								<div class="input-field">
									<input type="email" name="email" class="form-control" placeholder="Nhập Email..." required>
									@if ($errors->has('email'))
			              			 <span style="color: red;">
			              				 {{ array_first($errors->get('email')) }}
			              			 </span>
              						@endif
								</div>
								<div class="input-field">
									<input type="text" name="title" class="form-control" placeholder="Tiêu đề..." required>
									@if ($errors->has('title'))
			              			 <span style="color: red;">
			              				 {{ array_first($errors->get('title')) }}
			              			 </span>
              						@endif
								</div>
								<div class="input-field">
									<textarea name="content" class="form-control" placeholder="Nội dung..." required ></textarea>
									@if ($errors->has('content'))
			              			 <span style="color: red;">
			              				 {{ array_first($errors->get('content')) }}
			              			 </span>
              						@endif
								</div>
						       	<button type="submit" id="submit" class="btn btn-blue btn-effect">Gửi</button>
							</form>
						</div>
						
						<div class="col-md-5 wow animated fadeInRight">
							<address class="contact-details">
								<h3 style="color: white" >Hoặc liên hệ trực tiếp với tôi</h3>						
								<p><i class="fa fa-pencil"></i>Địa chỉ : <span>47 Đồng Kè</span> <span>Liên Chiểu - Đà Nẵng </span></p><br>
								<p><i class="fa fa-phone"></i>Số điện thoại : (935) 696969</p>
								<p><i class="fa fa-envelope"></i>hungpha,0307@gmail.com</p>
							</address>
						</div>
			
					</div>
				</div>
				</div>
			</section>
			<!-- end Social section -->
			
			<!-- 
			<section id="contact" >
				<div class="container">
					<div class="row">
						
						<div class="sec-title text-center wow animated fadeInDown">
							<h2>Contact</h2>
							<p>Leave a Message</p>
						</div>
						
						
						<div class="col-md-7 contact-form wow animated fadeInLeft">
							<form action="#" method="post">
								<div class="input-field">
									<input type="text" name="name" class="form-control" placeholder="Your Name...">
								</div>
								<div class="input-field">
									<input type="email" name="email" class="form-control" placeholder="Your Email...">
								</div>
								<div class="input-field">
									<input type="text" name="subject" class="form-control" placeholder="Subject...">
								</div>
								<div class="input-field">
									<textarea name="message" class="form-control" placeholder="Messages..."></textarea>
								</div>
						       	<button type="submit" id="submit" class="btn btn-blue btn-effect">Send</button>
							</form>
						</div>
						
						<div class="col-md-5 wow animated fadeInRight">
							<address class="contact-details">
								<h3>Contact Us</h3>						
								<p><i class="fa fa-pencil"></i>Phoenix Inc.<span>PO Box 345678</span> <span>Little Lonsdale St, Melbourne </span><span>Australia</span></p><br>
								<p><i class="fa fa-phone"></i>Phone: (415) 124-5678 </p>
								<p><i class="fa fa-envelope"></i>website@yourname.com</p>
							</address>
						</div>
			
					</div>
				</div>
			</section>
			end Contact section -->
			
			
		
		</main>

@stop