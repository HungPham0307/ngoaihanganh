@extends('templates.admin.master')
@section('main-admin')
      <div class="content-wrapper">
	  <div class="row user">
			<div class="col-md-12">
				<div class="profile">
				  <div class="info"><img class="user-img" src="/templates/admin/images/admin.jpg">
					<h4>
						@if(Session::has("name"))

					 {{Session::get("name")}}
					@endif
					</h4>
					<p></p>
				  </div>
				  <div class="cover-image"></div>
				</div>
			</div>
        <div class="page-title">
			
			
				<h3 style="margin-left: 37%; color:red">
					 @if(Session::has("msg"))
                        {{Session::get("msg")}}
                       @endif
				</h3>
			
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body  ">
				<form action="{{route('admin.contact.del')}}" method="post" id="xoa" >
				{{csrf_field()}}
					<table class="table table-hover table-bordered" id="sampleTable">
					  <thead>
						<tr>
						  <th style="text-align: center;">ID</th>
						  <th style="text-align: center;" >Tên người gửi </th>                     
						   <th style="text-align: center;" >Tiêu đề </th> 
						  <th style="text-align: center;" >Nội dung</th>
						  <th style="text-align: center;" >Email</th>
						  <th style="text-align: center;" >Ngày gửi</th>
						  <th style="text-align: center;" >
							<input type="submit" value="Delete" name="smXoa" class="xoa" onclick="return confirm('Bạn có chắc chắn muốn xóa không ?') " 
							style="border: 3px; border-radius: 3px; background-color: dodgerblue;">
						  </th>
						 
						</tr>
					  </thead>
					  <tbody class= "hienthigopy">
					
									@foreach($objContact as $val )

									@php 
                                    $id = $val ->id;
                                    $urlReply = route('admin.contact.getreply',$id);
                                    @endphp 
							
									<tr>
									    <td style="text-align: center;" >{{$id}}</td>
									    <td style="text-align: center;" >{{$val->name}}</td>
									    <td style="text-align: center;" >{{$val->title}}</td>
									    <td style="text-align: center;" >{{$val->content}}</td>
									    <td style="text-align: center;" >{{$val->email}}</td>
									    <td style="text-align: center;" >{{$val->created_at}}</td>
									    
									  <td style="text-align: center;" >
											<img src= "/templates/admin/images/edit.gif" />
										  <a href="{{$urlReply}}">Trả lời </a>
										  <img src= "/templates/admin/images/bin.gif" />
										  <input   type="checkbox" value="{{$id}}" name="xoa[]"/>
										 
										 
									  </td>
									 
									</tr>
						
									@endforeach
					
					  </tbody>
					</table>
				</form>
              </div>

			 <div class="pager">
				<ul>
			
					<li>{{$objContact->links()}}</li>
													
					
				</ul>
			</div>
			  

			  
			  
            </div>
          </div>
		  </div>
        </div>
      </div>
    </div>
    <!-- Javascripts-->
   
 <script type="text/javascript">
    function getTrangThai(id)
        {
            var url='/admin/contact/active/'+id;
            var tmp="#actice-"+id;
          
            $.ajax({
                url:url,
                dataType: "html",
                success: function(result) {
                   
                    $(tmp).html(result);
                },
            });
        }
</script>
  </body>
</html>
@stop