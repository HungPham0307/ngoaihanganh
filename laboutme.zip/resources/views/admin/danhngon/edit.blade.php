@extends('templates.admin.master')
@section('main-admin')
      <div class="content-wrapper">
		
        <div class="row user">
			<div class="col-md-12">
				<div class="profile">
				  <div class="info"><img class="user-img" src="/templates/admin/images/admin.jpg">
					<h4>@if(Session::has("name"))

					 {{Session::get("name")}}
					@endif</h4>
					<p></p>
				  </div>
				  <div class="cover-image"></div>
				</div>
			</div>
			<div class="page-title">
			
				<h4 style="margin-left: 37%; color: red;">
				
					@if(Session::has("msg"))
                        {{Session::get("msg")}}
                       @endif
					
				</h4>
			
			</div>
        
           
		   <div class="col-md-6" style="width: 100%;">
            <div class="card">
              <h3 class="card-title">Sửa thông tin</h3>
				<div class="card-body">
					<form action="{{route('admin.danhngon.postedit',$objDN->id)}}" method="post" enctype="multipart/form-data"  >
					{{csrf_field()}}
					  <div class="form-group">
						<label class="control-label">Tác Giả *</label>
						<input class="form-control" type="text" placeholder=" Tên tác giả.." required name="tacgia" value="{{$objDN->tacgia}}">
					  </div>
					 @if ($errors->has('tacgia'))
                            <span style="color: red;">{{ array_first($errors->get('tacgia')) }}</span>
                        @endif

                        @if($objDN->hinhanh != "")
						<div class="form-group">
                            <label>Ảnh cũ</label>
                            <img src="{{ $imgUrl }}/{{$objDN->hinhanh}}" width="120px" alt="Xóa ảnh" /> Xóa <input type="checkbox" name="delete_picture" value="1" />
                        </div>
					 @endif
					  <div class="form-group">
						<label class="control-label">Hình ảnh *</label>
						<input class="form-control" type="file" name="hinhanh" style="width: 30%;"  >
					  </div>
					  
					   <div class="form-group">
						<label class="control-label">Nội dung *</label>
						<textarea name="noidung"  rows="7" cols="90" class="input-medium" style="width: 100%;" required  >
						{{$objDN->noidung}}
						</textarea>
					  </div>
					   @if ($errors->has('noidung'))
                            <span style="color: red;">{{ array_first($errors->get('noidung')) }}</span>
                        @endif
					  
					  <div class="card-footer">
						<button class="btn btn-primary icon-btn" name="smeditDM" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Đồng ý</button>
					  </div>
					</form>
              </div>
             
            </div>
          </div>
		   
		   
          </div>
       </div>

  </body>
</html>
@stop